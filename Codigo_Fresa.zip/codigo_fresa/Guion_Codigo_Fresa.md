# Frutinovela: Código Fresa

Oct 20, 2026 · @Alvaro Gimenez

## Sinopsis y personajes

En el Mercado Central, alguien ha hackeado la báscula digital que decide qué fruta es "de primera" y cuál va al jugo. Fresa, la mejor hacker del cajón, tiene tres capítulos para descubrir al culpable antes de que todas terminen licuadas.

| Personaje | Rol | Rasgo dramático |
| --- | --- | --- |
| **Fresa Valentina** | Protagonista, hacker de sombrero blanco | Siempre trabaja con capucha verde (sus hojitas) y nunca duerme |
| **Piña Maximiliano** | Galán, jefe de seguridad del mercado | Duro por fuera, dulce por dentro; esconde un secreto |
| **Banana Esmeralda** | Villana, reina de la red oscura del frutero | Usa gafas de sol y siempre se resbala en el momento menos oportuno |
| **Limón Ricardo** | Mejor amigo de Fresa, experto en cifrado | Ácido, sarcástico, llora cuando lo exprimen emocionalmente |
| **Doña Sandía** | Matriarca del mercado | Enorme, sabia y llena de semillas (de verdad) |
| **Kiwi** | Becario nuevo | Pequeño, peludo y sospechosamente callado |

## Capítulo 1: «Error 404: Dulzura no encontrada»

**ESCENA 1 — INT. CAJÓN DE LAS FRUTAS ROJAS — NOCHE**

*Oscuridad. Solo brilla una pantalla. FRESA VALENTINA teclea con furia. Música de suspenso con violines.*

**FRESA:** (susurrando) Vamos... vamos... ¡Entré!

*En la pantalla aparece una banana sonriente con gafas de sol y el texto «PELADA FOREVER».*

**FRESA:** No puede ser... alguien reprogramó la báscula. ¡Mañana todas las fresas saldremos como «madura de más»!

*Entra LIMÓN RICARDO con una taza de té.*

**LIMÓN:** ¿Otra vez despierta a las tres de la mañana? Vas a terminar como pasa, Valentina.

**FRESA:** Ricardo, mira esto. El hackeo dejó una firma.

**LIMÓN:** (se acerca, se le cae la taza) Esa firma... es la de la Banda del Racimo. Pensé que estaban todos en el licuado.

*Zoom dramático a la cara de Fresa. Trueno.*

**ESCENA 2 — INT. OFICINA DE SEGURIDAD DEL MERCADO — DÍA**

*PIÑA MAXIMILIANO revisa cámaras. Fresa entra sin tocar.*

**PIÑA:** Usted otra vez. Le dije que este mercado no necesita hackers.

**FRESA:** Y yo le dije que su firewall tiene más agujeros que un queso suizo... perdón, que una frambuesa.

**PIÑA:** (se levanta, la corona le roza el techo) Cuidado con lo que dice, señorita.

**FRESA:** Alguien entró a la báscula anoche. Desde dentro del mercado.

*Silencio. Se miran. Música romántica de golpe.*

**PIÑA:** (casi sin voz) ...¿Desde dentro?

**FRESA:** Desde esta oficina, Maximiliano.

*Golpe de tambor. Corte a negro.*

## Capítulo 2: «Contraseña: traición123»

**ESCENA 3 — INT. PUESTO DE DOÑA SANDÍA — TARDE**

*Fresa y Limón piden consejo. DOÑA SANDÍA se abanica con una hoja de lechuga.*

**DOÑA SANDÍA:** Mija, en este mercado nadie es lo que parece. Yo, por ejemplo, soy noventa por ciento agua y diez por ciento chisme.

**FRESA:** Doña Sandía, ¿usted sabe algo de la Banda del Racimo?

**DOÑA SANDÍA:** (escupe una semilla, dramática) Sé que su líder nunca fue atrapada. Le decían «La Resbalosa».

*Fresa y Limón se miran. Violines.*

**ESCENA 4 — INT. SERVIDOR DEL MERCADO (UNA NEVERA VIEJA) — NOCHE**

*Fresa conecta su laptop. Limón vigila la puerta. Las pantallas se llenan de código verde.*

**LIMÓN:** Valentina, el registro de accesos... no es de Maximiliano.

**FRESA:** ¿Entonces de quién?

**LIMÓN:** (traga saliva) El usuario es... «kiwi\_becario».

*Se abre la puerta lentamente. Aparece KIWI, bajo la luz de la nevera.*

**KIWI:** (con voz grave, totalmente distinta) Buenas noches, señorita Fresa.

**FRESA:** ¡Kiwi! Pero... ¡si tú no hablabas!

**KIWI:** Los callados somos los que más escuchamos. Trabajo para Ella.

*Se escucha un deslizamiento. Entra BANANA ESMERALDA, gafas de sol de noche.*

**BANANA:** Hola, Fresita. Tanto tiempo sin vernos... desde que me dejaste en el frutero de la abuela.

**FRESA:** (temblando) No... ¡tú eres mi hermana de cesta!

*Limón deja caer su laptop. Doña Sandía, desde lejos, grita «¡Lo sabía!». Corte a negro.*

## Capítulo 3: «Ctrl + Z al corazón»

**ESCENA 5 — INT. CENTRO DE CONTROL DE LA BÁSCULA — MADRUGADA**

*Duelo de laptops. Fresa a un lado, Banana al otro. Luces rojas parpadean. Cuenta regresiva en pantalla: 00:60.*

**BANANA:** En un minuto, la báscula mandará a todas las fresas a la licuadora. Y yo seré la reina del frutero.

**FRESA:** (tecleando) No si cambio la lógica de la báscula antes.

**BANANA:** ¡Kiwi, bloquéala!

*Kiwi duda. Mira a Fresa. Mira a Banana.*

**KIWI:** No, Esmeralda. Ella me enseñó a usar el teclado cuando nadie más lo hizo.

*Kiwi desconecta un cable. Banana grita y se resbala con su propia cáscara.*

**BANANA:** ¡Nooo! ¡Otra vez la cáscara!

*Entra PIÑA MAXIMILIANO con el equipo de seguridad (tres uvas con chaleco).*

**PIÑA:** Quedas detenida, Banana Esmeralda, por fraude de peso y abuso de potasio.

*Pantalla: 00:03... 00:02... Fresa pulsa Enter. La báscula muestra «FRESAS: DE PRIMERA». Todos celebran.*

**ESCENA 6 — EXT. TECHO DEL MERCADO — AMANECER**

*Fresa y Piña miran el sol. Música romántica a todo volumen.*

**PIÑA:** Me equivoqué con usted, Valentina. Este mercado sí necesita una hacker.

**FRESA:** Y yo me equivoqué con usted. No es tan espinoso como parece.

**PIÑA:** (se acerca) Hay algo que debo confesarle... no soy una piña cualquiera.

**FRESA:** ¿Qué quiere decir?

**PIÑA:** Soy... una piña colada. Mi padre era un coco.

*Fresa jadea. Zoom triple a su cara. Trueno, aunque el cielo está despejado.*

**VOZ EN OFF (Limón, llorando):** No se pierdan el próximo capítulo de *Código Fresa*... ¡donde el amor se descifra, pero el pasado se encripta!

*Logo final: una fresa con capucha y un candado. FIN DE TEMPORADA.*

---

**Notas de producción:** cada capítulo dura de 1 a 2 minutos, ideal para video corto vertical. Para la versión con IA, describe a cada fruta con ojos grandes, boca expresiva y un accesorio fijo (la capucha de Fresa, las gafas de Banana, la corona de Piña) para que se reconozcan en cada escena.
